function getSessionInformation() {
  return JSON.parse(sessionStorage.getItem('sessionInfo') || 'null');
}

function updateSessionInformation(property, value) {
  const sessionInfo = JSON.parse(sessionStorage.getItem('sessionInfo') || 'null');
  sessionInfo[property] = value;
  sessionStorage.setItem('sessionInfo', JSON.stringify(sessionInfo));
}

function getItemDetails(catalog, id) {
  return catalog.find(item => item.id === id);
}

function getItemsInformation(catalog, items) {
  return Object.keys(items).map(id => ({
    ...getItemDetails(catalog, id),
    quantity: items[id],
  }));
}
