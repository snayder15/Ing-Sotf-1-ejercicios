class CatalogItem extends React.Component {
  constructor(props) {
    super(props);
  }

  detailView = (
    item,
    onAdd,
    onRemove,
    isOnWishList,
    hideCartActions,
    onAddToWishList,
    onRemoveFromWishList) => (<React.Fragment>
    {item && <div className="detail-item-container">
      <div className="detail-img">
        <div className="detail-item detail-item-image">
          <img src={item.src} />
          <div className="detail-item-actions">
            <CatalogItemActions
              item={item}
              onAdd={onAdd}
              onRemove={onRemove}
              onAddToWishList={onAddToWishList}
              onRemoveFromWishList={onRemoveFromWishList}
              isOnWishList={isOnWishList}
              hideCartActions={hideCartActions}
            />
          </div>
        </div>
      </div>
      <div className="detail-info">
        <div className="detail-item detail-item-name">
          {item.name}
        </div>
        <div className="detail-item detail-item-description">
          {item.description}
        </div>
        <div className="detail-item detail-item-price">
          ${item.price}
        </div>
      </div>
    </div>}
  </React.Fragment>)

  listView = (
    item,
    onAdd,
    onRemove,
    onShowDetail,
    isOnWishList,
    hideCartActions,
    onAddToWishList,
    onRemoveFromWishList) => (
    <div className="item-card">
      <div className="item-image" onClick={onShowDetail}>
        <img src={item.src} />
      </div>
      <div className="item-information">
        <div className="item item-name" onClick={onShowDetail}>
          {item.name}
        </div>
        <div className="item item-isbn">
          isbn: {item.id}
        </div>
        <div className="item item-author">
          {item.author}
        </div>
        <div className="item item-price">
          ${item.price}
        </div>
      </div>
      <div className="item item-actions">
        <CatalogItemActions
          item={item}
          onAdd={onAdd}
          onRemove={onRemove}
          isOnWishList={isOnWishList}
          onAddToWishList={onAddToWishList}
          onRemoveFromWishList={onRemoveFromWishList}
          hideCartActions={hideCartActions}
        />
      </div>
    </div>)

  render() {
    const {
      item,
      onAdd,
      onRemove,
      onShowDetail,
      isOnWishList,
      hideCartActions,
      onAddToWishList,
      onRemoveFromWishList,
      mode,
    } = this.props;

    return (
      mode === 'list' ? this.listView(item,
        onAdd,
        onRemove,
        onShowDetail,
        isOnWishList,
        hideCartActions,
        onAddToWishList,
        onRemoveFromWishList) :
        this.detailView(item,
          onAdd,
          onRemove,
          isOnWishList,
          hideCartActions,
          onAddToWishList,
          onRemoveFromWishList)
    );
  }
}
