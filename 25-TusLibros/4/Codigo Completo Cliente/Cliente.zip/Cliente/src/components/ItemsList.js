class ItemsList extends React.Component {
  constructor(props) {
    super(props);
  }

  getTotal(items) {
    return items.reduce( (total, item) => total += (item.quantity * item.price), 0);
  }

  render() {
    const { items, showTotal } = this.props;
    return (
      <div className="ticket-view">
        {showTotal && <div className="ticket-total">
          Order Total: ${this.getTotal(items)}
        </div>}
        {items.map(item => (<div className="ticket-item-container" key={item.id}>
          <div className="ticket-item ticket-item-image">
            <img src={item.src} />
          </div>
          <div className="ticket-item ticket-item-name">
            {item.name}
          </div>
          <div className="ticket-item ticket-item-quantity">
            <b>Qty.:</b> {item.quantity}
          </div>
          <div className="ticket-item ticket-item-total">
            <b>Total:</b> ${item.price * item.quantity}
          </div>
          </div>))}
      </div>
    );
  }
}
