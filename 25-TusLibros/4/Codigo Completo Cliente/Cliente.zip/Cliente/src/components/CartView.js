class CartView extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      items: [],
    };
    this.onAdd = this.onAdd.bind(this);
    this.onRemove = this.onRemove.bind(this);
    this.onShowDetail = this.onShowDetail.bind(this);
  }

  componentDidMount() {
    const { cartId } = getSessionInformation();
    getLocalAsJson(`listCart?cartId=${cartId}`)
      .then(async function (response) {
        const dataAsJson = await response.json();
        if (response.status === 404) {
          throw dataAsJson;
        }
        const { catalog } = getSessionInformation();
        const items = getItemsInformation(catalog, dataAsJson);
        this.getTotal(items);
        this.setState({ items });
      }.bind(this))
      .catch(function (errorMessage) {
        const { setError } = this.props;
          setError(errorMessage);
      }.bind(this));
  }

  getTotal (items) {
    const total = items.reduce( (total, item) => total += (item.quantity * item.price), 0);
    this.setState({ total });
  }

  onCheckout() {
    const { cartId, id } = getSessionInformation();
    const { router } = this.props;
    getLocalAsJson(`checkoutCart?cartId=${cartId}&clientId=${id}`)
    .then(async function (response) {
      const dataAsJson = await response.json();
      if (response.status === 404) {
        throw dataAsJson;
      }
      let ticketItems = {};
      Object.keys(dataAsJson).forEach(item => {
        ticketItems[item] = dataAsJson[item].qty;
      });
      const { catalog } = getSessionInformation();
      const items = getItemsInformation(catalog, ticketItems);
      router.navigate('/ticket', { ticket: items })
    }.bind(this))
    .catch(function (errorMessage) {
      const { setError } = this.props;
      setError(errorMessage);
    }.bind(this));
  }

  updateCart(items) {
    const cartItems = items.filter(item => item.quantity > 0);
    this.setState({ items: cartItems });
    this.getTotal(cartItems);
  }

  onAdd(id) {
    const { cartId } = getSessionInformation();
    const { items } = this.state;
    let item = items.find(c => c.id === id);
    getLocalAsJson(`addToCart?cartId=${cartId}&bookIsbn=${id}&bookQuantity=1`)
    .then(async function (response) {
      const dataAsJson = await response.json();
      if (response.status === 404) {
        throw dataAsJson;
      }
      item.quantity++;
      this.updateCart(items);
    }.bind(this))
    .catch(function (errorMessage) {
      const { setError } = this.props;
        setError(errorMessage);
    }.bind(this));
  }

  onRemove(id) {
    const { cartId } = getSessionInformation();
    const { items } = this.state;
    let item = items.find(c => c.id === id);
    getLocalAsJson(`removeFromCart?cartId=${cartId}&bookIsbn=${id}`)
    .then(async function (response) {
      const dataAsJson = await response.json();
      if (response.status === 404) {
        throw dataAsJson;
      }
      item.quantity--;
      this.updateCart(items);
    }.bind(this))
    .catch(function (errorMessage) {
      const { setError } = this.props;
      setError(errorMessage);
    }.bind(this));
  }

  goToCatalog() {
    const { router } = this.props;
    router.navigate('/catalog', {});
  }

  onShowDetail(id) {
    const { router } = this.props;
    router.navigate('/detail', { selectedBook: id });
  }

  render() {
    const { router } = this.props;
    const { items, total } = this.state;
    return (
      <div className="catalog-view">
        <React.Fragment>
          {(items && items.length) ?
          (<Catalog
            className="catalog"
            items={items}
            onRemove={this.onRemove}
            onAdd={this.onAdd}
            onShowDetail={this.onShowDetail}
            mode="list"
          />) :
          (<EmptySection
            router={router}
            label="Your cart is empty"
          />
          )}
          
          <div className="cart-total">
            <div className="items-total">
              TOTAL ${total}
            </div>
            <Button
              className="cart-total-btn"
              color='inherit'
              onClick={() => this.onCheckout()}
              disabled={items.length === 0}
              >
              Checkout
            </Button>
          </div>
        </React.Fragment>
      </div>
    );
  }
}
