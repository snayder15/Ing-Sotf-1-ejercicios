class MyToolBarComponent extends React.Component {
  constructor(props) {
    super(props)
  }

  render() {
    const {
      router,
      title,
      classes,
    } = this.props

    const isAuthenticated = !!getSessionInformation();

    const isLanding = router.current() === '/';
    const navBarClassName = `bookstore-navbar ${isLanding ? 'create-cart-navbar' : ''}`;
    const menu = [
      {
        name: 'catalog',
        label: 'Catalog',
        onclick: () => router.navigate('/catalog', {}),
      },
      {
        name: 'wishlist',
        label: 'Wishlist',
        onclick: () => router.navigate('/wishlist', {}),
      },
      {
        name: 'purchases',
        label: 'My Purchases',
        onclick: () => router.navigate('/purchases', {}),
      },
      {
        name: 'cart',
        icon: 'shopping_cart',
        onclick: () => router.navigate('/cart', {}),
      },
      {
        name: 'logout',
        icon: 'logout',
        onclick: () => {
          sessionStorage.removeItem('sessionInfo');
          router.navigate('/', {
            authentication: null,
          });
        },
      },
    ];

    return (
      <div className={classes.rootToolBar}>
        <AppBar position='static' className={navBarClassName}>
          <Toolbar>
            <Typography variant='h6' className={classes.title}>
              {title}
            </Typography>
            {isAuthenticated && menu.map(m => (
            m.icon ?
              <IconButton
                edge='start'
                className="menu-item-icon"
                color='inherit'
                onClick={m.onclick}
                key={m.name}
              >
                <Icon>{m.icon}</Icon>
              </IconButton> :
            <a
              className="menu-items"
              key={m.name}
              onClick={m.onclick}>
                {m.label}
            </a>
            ))}
          </Toolbar>
        </AppBar>
      </div>
    )
  }

}

// Add style
const MyToolBar = withStyles(styles, {
  withTheme: true
})(MyToolBarComponent)
