class PurchasesView extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      items: [],
    }
  }

  componentDidMount() {
    
    const { catalog, id, password } = getSessionInformation();
    getLocalAsJson(`listPurchases?clientId=${id}&password=${password}`)
      .then(async function (response) {
        const dataAsJson = await response.json();
        if (response.status === 404) {
          throw dataAsJson;
        }
        let ticketItems = {};
        Object.keys(dataAsJson).forEach(item => {
          ticketItems[item] = dataAsJson[item].qty;
        });
        const items = getItemsInformation(catalog, ticketItems);
        this.setState({ items });
      }.bind(this))
      .catch(function (errorMessage) {
        const { setError } = this.props;
        setError(errorMessage);
      }.bind(this));
  }

  render() {
    const { items } = this.state;
    const { router } = this.props;
    return (
        items.length ? 
          <ItemsList items={items} showTotal={false} /> :
        (<EmptySection
          router={router}
          label="You don't have any purchases on your history"
        />
        )
    );
  }
}
