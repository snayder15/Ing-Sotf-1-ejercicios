class CreateCartView extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      authentication: {
        id: '',
        password: '',
      },
      showPassword: false,
    }
  };

  onUpdate(property, ev) {
    const { authentication } = this.state;

    this.setState({
      authentication: {
        ...authentication,
        [property]: ev.target.value,
      },
    })
  }

  toggleVisibility() {
    const { showPassword } = this.state;
    this.setState({ showPassword: !showPassword });
  }

  onSubmit() {
    const { router } = this.props;
    const { id, password } = this.state.authentication;
    if (!id || !password) {
      this.setState({ dirty: true })
    } else {
      this.setState({ dirty: false })
      getLocalAsJson(`createCart?clientId=${id}&password=${password}`)
      .then(async function(response) {
        const dataAsJson = await response.json();
        if (response.status === 404) {
          throw dataAsJson;
        }
        sessionStorage.setItem('sessionInfo', JSON.stringify({ id, password, cartId: dataAsJson }));
        router.navigate('/catalog', {});
      })
      .catch(function(errorMessage){
        const { setError } = this.props;
        setError(errorMessage);
      }.bind(this))
    }
  }

  render() {

    const { dirty, showPassword } = this.state;
    const { id, password } = this.state.authentication;

    return (
      <div className="create-cart-view">
        <div className="create-cart-form">
          <Typography component='h2' className="create-cart-title">
            Please enter your Client Id and Password
          </Typography>
          <FormControl margin='dense' fullWidth variant='outlined'>
            <InputLabel htmlFor='id-input'>Id</InputLabel>
            <Input
              id='id-input'
              value={id}
              onChange={ev => this.onUpdate('id', ev)}
              rows='1'
            />
            {dirty && !id && (<div className="create-cart-required">
              Id is required
            </div>)}
          </FormControl>
          <FormControl margin='dense' fullWidth variant='outlined'>
              <InputLabel htmlFor='password-input'>Password</InputLabel>
              <Input
                id='password-input'
                type={showPassword ? 'text' : 'password'}
                value={password}
                onChange={ev => this.onUpdate('password', ev)}
                rows='1'
              />
              <Tooltip interactive title={showPassword ? 'hide password' : 'show password'}>
                <Icon onClick={() => this.toggleVisibility()} className="password-icon">{showPassword ? 'visibility' : 'visibility_off'}</Icon>
              </Tooltip>
              {dirty && !password && (<div className="create-cart-required">
                Password is required
              </div>)}
          </FormControl>

          <Button
            className="create-cart-button"
            onClick={() => this.onSubmit()}>
            Create cart
        </Button>
        </div>
      </div>
    );
  }
}
