class EmptySection extends React.Component {
  constructor(props) {
    super(props);
  }

  goToCatalog() {
    const { router } = this.props;
    router.navigate('/catalog', {});
  }

  render() {
    const { label } = this.props;
    return (
      <div className="catalog-view">
          <div className="empty-cart">
            <div>
              {label}
            </div>
            <div>
              Go to the <a className="catalog-link" onClick={() => this.goToCatalog()}>catalog</a> to start shopping
            </div>
          </div>
      </div>
    );
  }
}
