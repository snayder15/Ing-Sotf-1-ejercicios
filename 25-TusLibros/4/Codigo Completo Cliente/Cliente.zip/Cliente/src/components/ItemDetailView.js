class ItemDetailView extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      item: null,
      wishList: [],
    }

    this.onAdd = this.onAdd.bind(this);
    this.onRemove = this.onRemove.bind(this);
  }

  componentDidMount() {
    const { cartId } = getSessionInformation();
    getLocalAsJson(`listCart?cartId=${cartId}`)
      .then(async function (response) {
        const dataAsJson = await response.json();
        if (response.status === 404) {
          throw dataAsJson;
        }
        const { catalog } = getSessionInformation();
        let { item } = this.props;
        item = catalog.find(i => i.id === item);
        const items = getItemsInformation(catalog, dataAsJson);
        const itemInCart = items.find(i => i.id === item.id);
        if (itemInCart) {
          item.quantity = itemInCart.quantity;
        } else {
          item.quantity = 0;
        }
        this.setState({ item });
      }.bind(this))
      .catch(function (errorMessage) {
        const { setError } = this.props;
        setError(errorMessage);
      }.bind(this));
  }

  onAdd(id) {
    const { cartId } = getSessionInformation();
    const { item } = this.state;
    getLocalAsJson(`addToCart?cartId=${cartId}&bookIsbn=${id}&bookQuantity=1`)
      .then(async function (response) {
        const dataAsJson = await response.json();
        if (response.status === 404) {
          throw dataAsJson;
        }
        item.quantity++;
        this.setState({ item });
      }.bind(this))
      .catch(function (errorMessage) {
        const { setError } = this.props;
        setError(errorMessage);
      }.bind(this));
  }

  onRemove(id) {
    const { cartId } = getSessionInformation();
    const { item } = this.state;
    getLocalAsJson(`removeFromCart?cartId=${cartId}&bookIsbn=${id}`)
      .then(async function (response) {
        const dataAsJson = await response.json();
        if (response.status === 404) {
          throw dataAsJson;
        }
        item.quantity--;
        this.setState({ item });
      }.bind(this))
      .catch(function (errorMessage) {
        const { setError } = this.props;
        setError(errorMessage);
      }.bind(this));
  }

  render() {
    const { item } = this.state;
    return (
      (item && <Catalog
        className="catalog"
        items={[item]}
        onRemove={this.onRemove}
        onAdd={this.onAdd}
        mode="detail"
      />)
    );
  }
}
