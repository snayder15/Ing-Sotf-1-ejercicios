class CatalogView extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      catalog: [],
      error: null,
      cartItems: {},
      filters: {
        byName: '',
        byAuthor: [],
        byPrice: {
          min: '',
          max: '',
        },
        orderBy: '',
      },
    };
    this.onAdd = this.onAdd.bind(this);
    this.onRemove = this.onRemove.bind(this);
    this.onShowDetail = this.onShowDetail.bind(this);
    this.onFilter = this.onFilter.bind(this);
  }

  onFilter(filters) {
    this.setState({ filters });
  }
  
  getItemQuantity(id) {
    return (this.state.cartItems[id] || 0);
  }
  
  componentDidMount() {
    const { cartId } = getSessionInformation();
    getLocalAsJson(`listCart?cartId=${cartId}`)
    .then(async function (response) {
      const dataAsJson = await response.json();
      if (response.status === 404) {
        throw dataAsJson;
      }
      this.setState({ cartItems: dataAsJson })
    }.bind(this))
    .catch(function (errorMessage) {
      const { setError } = this.props;
      setError(errorMessage);
    }.bind(this));

    getLocalAsJson('getCatalog')
    .then(async function (response) {
      const dataAsJson = await response.json();
      if (response.status === 404) {
        throw dataAsJson;
      }
      const catalog = Object.keys(dataAsJson).map(id => ({
        ...dataAsJson[id],
        id,
        quantity: this.getItemQuantity(id),
      }));
      updateSessionInformation('catalog', catalog);
      this.setState({ catalog });
    }.bind(this))
    .catch(function (errorMessage) {
      const { setError } = this.props;
        setError(errorMessage);
    }.bind(this));
  }

  onAdd(id) {
    const { cartId } = getSessionInformation();
    const { catalog } = this.state;
    let catalogItem = catalog.find(c => c.id === id);
    getLocalAsJson(`addToCart?cartId=${cartId}&bookIsbn=${id}&bookQuantity=1`)
    .then(async function (response) {
      const dataAsJson = await response.json();
      if (response.status === 404) {
        throw dataAsJson;
      }
      catalogItem.quantity++;
      this.setState({ catalog });
    }.bind(this))
    .catch(function (errorMessage) {
      const { setError } = this.props;
      setError(errorMessage);
    }.bind(this));
  }

  onRemove(id) {
    const { cartId } = getSessionInformation();
    const { catalog } = this.state;
    let catalogItem = catalog.find(c => c.id === id);
    getLocalAsJson(`removeFromCart?cartId=${cartId}&bookIsbn=${id}`)
    .then(async function (response) {
      const dataAsJson = await response.json();
      if (response.status === 404) {
        throw dataAsJson;
      }
      catalogItem.quantity--;
      this.setState({ catalog });
    }.bind(this))
    .catch(function (errorMessage) {
      const { setError } = this.props;
        setError(errorMessage);
    }.bind(this));
  }

  onShowDetail(id) {
    const { router } = this.props;
    router.navigate('/detail', { selectedBook: id });
  }

  filterItems(items) {
    const { filters } = this.state;
    const { byName, byAuthor, byPrice } = filters;
    const filterRegexp = new RegExp(byName, 'i');
    return items.filter(item => {
      let matches = true;
      if (byName) {
        matches = matches && (item.name.match(filterRegexp));
      }
      if (byAuthor.length) {
        matches = matches && (byAuthor.length && byAuthor.includes(item.author));
      }
      if (byPrice.min) {
        matches = matches && (byPrice.min <= item.price);
      }
      if (byPrice.max) {
        matches = matches && (byPrice.max >= item.price);
      }
        return matches;
      }
    )
  }

  sortItems(items) {
    const { filters } = this.state;
    const { orderBy } = filters;
    if (orderBy) {
      if (orderBy === 'name') {
        items = items.sort((a, b) => {
          if (a.name.toLowerCase() <= b.name.toLowerCase()) {
            return -1;
          } else {
            return 1
          }
        });
      } else if(orderBy === 'price-low') {
        items = items.sort((a, b) => {
          if (a.price <= b.price) {
            return -1;
          } else {
            return 1
          }
        });
      } else if (orderBy === 'price-high') {
        items = items.sort((a, b) => {
          if (a.price >= b.price) {
            return -1;
          } else {
            return 1
          }
        });
      }
    }
    return items;
  }

  render() {
    const { catalog, filters } = this.state;
    const { setError } = this.props;
    return (
      <div className="catalog-view">
        <div className="filters">
          <Filters 
            onFilter={this.onFilter}
            filters={filters}
          />
        </div>
        <Catalog
          className="catalog"
          items={this.sortItems(this.filterItems(catalog))}
          onRemove={this.onRemove}
          onAdd={this.onAdd}
          onShowDetail={this.onShowDetail}
          setError={setError}
          mode="list"
        />
      </div>
    );
  }
}
