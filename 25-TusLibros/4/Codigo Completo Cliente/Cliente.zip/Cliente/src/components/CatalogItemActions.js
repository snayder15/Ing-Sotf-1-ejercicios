class CatalogItemActions extends React.Component {
  constructor(props) {
    super(props);
  }

  render() {
    const {
      item,
      onAdd,
      onRemove,
      onAddToWishList,
      onRemoveFromWishList,
      isOnWishList,
      hideCartActions,
    } = this.props;

    const isDisabled = item.quantity === 0;
    const removeClassName = `action action-remove ${isDisabled ? 'disabled' : ''}`;
    return (
      <div className="catalog-actions-container">
        {!hideCartActions && (<div className="catalog-actions"> 
          <div className={removeClassName}>
            <Button
              disabled={item.quantity === 0}
              color='inherit'
              onClick={onRemove}>
              -
            </Button>
          </div>
          <div className="action quantity">
            {item.quantity}
          </div>
          <div className="action action-add">
            <Button
              color='inherit'
              onClick={onAdd}>
              +
            </Button>
          </div>
        </div>)}
        <div className="item item-wishlist">
          <Button
            className="wishlist-button"
            color='inherit'
            onClick={isOnWishList ? onRemoveFromWishList : onAddToWishList}>
            {`${isOnWishList ? 'Remove from' : 'Add to'} Wishlist `}
            <Icon className="favorite-icon">{isOnWishList ? 'favorite' : 'favorite_border'}</Icon>
          </Button>
        </div>
      </div>
    );
  }
}
