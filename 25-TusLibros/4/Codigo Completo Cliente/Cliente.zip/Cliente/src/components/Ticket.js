class Ticket extends React.Component {
  constructor(props) {
    super(props);
  }

  render() {
    const { items } = this.props;
    return (
      <ItemsList items={items} showTotal />
    );
  }
}
