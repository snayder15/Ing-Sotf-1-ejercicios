class Catalog extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      wishList: []
    };
  }

  componentDidMount() {
    const { id } = getSessionInformation();
    getLocalAsJson(`listWishlist?clientId=${id}`)
    .then(async function (response) {
      const dataAsJson = await response.json();
      if (response.status === 404) {
        throw dataAsJson;
      }
      this.setState({ wishList: Object.keys(dataAsJson) });
    }.bind(this))
    .catch(function (errorMessage) {
      const { setError } = this.props;
      setError(errorMessage);
    }.bind(this));
  }

  onAddToWishList(itemId) {
    const { id } = getSessionInformation();
    getLocalAsJson(`addToWishList?clientId=${id}&bookIsbn=${itemId}`)
    .then(async function (response) {
      const dataAsJson = await response.json();
      if (response.status === 404) {
        throw dataAsJson;
      }
      this.setState({ wishList: Object.keys(dataAsJson) });
    }.bind(this))
    .catch(function (errorMessage) {
      const { setError } = this.props;
      setError(errorMessage);
    }.bind(this));
  }

  onRemoveFromWishList(itemId) {
    const { id } = getSessionInformation();
    getLocalAsJson(`removeFromWishList?clientId=${id}&bookIsbn=${itemId}`)
    .then(async function (response) {
      const dataAsJson = await response.json();
      if (response.status === 404) {
        throw dataAsJson;
      }
      this.setState({ wishList: Object.keys(dataAsJson) });
    }.bind(this))
    .catch(function (errorMessage) {
      const { setError } = this.props;
      setError(errorMessage);
    }.bind(this));
  }
  
  render() {
    const {
      items,
      onAdd,
      onRemove,
      onShowDetail,
      mode,
    } = this.props;
    const { wishList } = this.state;
    const showDetails = (id) => (!!onShowDetail ? (() => onShowDetail(id)) : (() => {}));
    return (
      <div className="catalog">
        {items.map(item => (
          <CatalogItem
            mode={mode}
            key={item.name}
            item={item}
            isOnWishList={wishList.includes(item.id)}
            onAdd={() => onAdd(item.id)}
            onRemove={() => onRemove(item.id)}
            onShowDetail={showDetails(item.id)}
            onAddToWishList={() => this.onAddToWishList(item.id)}
            onRemoveFromWishList={() => this.onRemoveFromWishList(item.id)}
          />
        ))}
      </div>
    );
  }
}
