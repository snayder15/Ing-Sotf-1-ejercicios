class App extends React.Component {
  constructor(props) {
    super(props);

    const isAuthenticated = !!getSessionInformation();

    this.state = {
      path: isAuthenticated ? '/catalog' : '/',
      selectedBook: null,
      ticket: null,
      error: null,
    };
  }

  render() {
    const isLanding = this.state.path === '/';
    const containerClassName = `books-container ${isLanding ? 'landing' : ''}`;

    const title = 'Book Store';
    let content = null;
    const router = {
      current: () => this.state.path,
      navigate: (path, state) => {
        // http://es6-features.org/#SpreadOperator
        this.setState({ ...state, path: path })
      },
    };

    const { error } = this.state;

    const setError = errorMessage => {
      this.setState({ error: {
        message: errorMessage,
      } })
    }

    if (this.state.path === '/') {
      content = (<CreateCartView
        router={router}
        setError={setError}
      />);
    } else if (this.state.path === '/catalog') {
      content = (<CatalogView
        router={router}
        setError={setError}
      />);
    } else if (this.state.path === '/detail') {
      content = (<ItemDetailView
        router={router}
        item={this.state.selectedBook}
        setError={setError}
      />);
    } else if (this.state.path === '/cart') {
      content = (<CartView
        router={router}
        catalog={this.state.catalog}
        setError={setError}
      />);
    } else if (this.state.path === '/purchases') {
      content = (<PurchasesView
        router={router}
        catalog={this.state.catalog}
        setError={setError}
      />);
    } else if (this.state.path === '/ticket') {
      content = (<Ticket
        router={router}
        items={this.state.ticket}
        setError={setError}
      />);
    } else if (this.state.path === '/wishlist') {
      content = (<WishList
        router={router}
        setError={setError}
      />);
    }
    return (
      <div>
        <MyToolBar
          title={title}
          router={router}
        />
        <Container 
          className={containerClassName}
          maxWidth={false}>
          <div className="books-content">
            {content}
          </div>
        </Container>
        <ErrorSnackbar
          message={error && error.message}
          onClose={() => this.setState({ error: null })}
          open={!!error}
        />
      </div>
    );
  }
}
