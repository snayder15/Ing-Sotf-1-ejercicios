class ErrorSnackbar extends React.Component {
  constructor(props) {
    super(props);
  }

  render() {
    const { message, onClose, open } = this.props;
    return (<Snackbar
      className="error-snackbar"
      message={message}
      open={open}
      onClose={onClose}
      autoHideDuration={2000}
      anchorOrigin={{vertical: 'top', horizontal: 'center'}}
    />)
  }
}
