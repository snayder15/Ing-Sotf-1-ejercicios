class Filters extends React.Component {
  constructor(props) {
    super(props);
  }

  filterByName(ev) {
    const { filters, onFilter } = this.props;
    onFilter({
      ...filters,
      byName: ev.target.value,
    })
  }

  filterByAuthor(ev, name) {
    const { filters, onFilter } = this.props;
    let { byAuthor: authors } = filters;
    if (ev.target.checked) {
      authors.push(name);
    } else {
      authors = authors.filter(author => author !== name)
    }

    onFilter({
      ...filters,
      byAuthor: authors,
    })
  }

  filterByPrice(ev, type) {
    const { filters, onFilter } = this.props;
    const { byPrice } = filters;

    onFilter({
      ...filters,
      byPrice: {
        ...byPrice,
        [type]: ev.target.value,
      },
    })
  }

  getAuthors() {
    const { catalog } = getSessionInformation();
    const authorNames = {};
    catalog.map(item => authorNames[item.author] = true);
    return Object.keys(authorNames);
  }

  orderBy(ev) {
    const { filters, onFilter } = this.props;

    onFilter({
      ...filters,
      orderBy: ev.target.value,
    })
  }

  render() {
    const { catalog } = getSessionInformation();
    const { filters } = this.props;

    return catalog ?
      (<div className="filters-container">
        <div className="filter-item order-by">
          <div className="filter-label">Order By</div>
          <Select
            className="width100"
            value={filters.orderBy}
            onChange={ev => this.orderBy(ev)}
          >
            <MenuItem value="name">Name</MenuItem>
            <MenuItem value="price-low"> Lowest Price </MenuItem>
            <MenuItem value="price-high"> Highest Price </MenuItem>

          </Select>
        </div>
        <div className="filter-item by-name">
          <div className="filter-label">Name</div>
          <Input
            className="width100"
            value={filters.byName}
            onChange={ev => this.filterByName(ev)}
            rows='1'
          />
        </div>
        <div className="filter-item by-author">
          <div className="filter-label">Author</div>
          {this.getAuthors().map(author => (
            <div key={author}>
              <Checkbox
                checked={filters.byAuthor.includes(author)}
                onChange={ev => this.filterByAuthor(ev, author)}
              />
              {author}
            </div>
          ))}
        </div>
        <div className="filter-item by-price">
          <div className="filter-label">Price</div>
          <div className="filter-item filter-min">
            <div className="filter-sublabel">Min</div>
            <Input
              className="width100"
              value={filters.byPrice.min}
              onChange={ev => this.filterByPrice(ev, 'min')}
              rows='1'
              type="number"
            />
          </div>
          <div className="filter-item filter-max">
            <div className="filter-sublabel">Max</div>
            <Input
              className="width100"
              value={filters.byPrice.max}
              onChange={ev => this.filterByPrice(ev, 'max')}
              rows='1'
              type="number"
            />
          </div>
        </div>
      </div>) :
      (<div></div>);
  }
}
