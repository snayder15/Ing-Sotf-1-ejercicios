class WishList extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      items: []
    };
  }

  componentDidMount() {
    const { id, catalog } = getSessionInformation();
    getLocalAsJson(`listWishlist?clientId=${id}`)
    .then(async function (response) {
      const dataAsJson = await response.json();
      if (response.status === 404) {
        throw dataAsJson;
      }
      const items = getItemsInformation(catalog, dataAsJson);
      this.setState({ items });
    }.bind(this))
    .catch(function (errorMessage) {
      const { setError } = this.props;
      setError(errorMessage);
    }.bind(this));
  }

  onMoveToCart(itemId) {
    // const { id } = getSessionInformation();
    // getLocalAsJson(`addToWishList?clientId=${id}&bookIsbn=${itemId}`)
    // .then(async function (response) {
    //   const dataAsJson = await response.json();
    //   if (response.status === 404) {
    //     throw dataAsJson;
    //   }
    //   this.setState({ wishList: Object.keys(dataAsJson) });
    // }.bind(this))
    // .catch(function (errorMessage) {
    //   const { setError } = this.props;
    //   setError(errorMessage);
    // }.bind(this));
  }

  onRemoveFromWishList(itemId) {
    const { id, catalog } = getSessionInformation();
    getLocalAsJson(`removeFromWishList?clientId=${id}&bookIsbn=${itemId}`)
    .then(async function (response) {
      const dataAsJson = await response.json();
      if (response.status === 404) {
        throw dataAsJson;
      }
      const items = getItemsInformation(catalog, dataAsJson);
      this.setState({ items });
    }.bind(this))
    .catch(function (errorMessage) {
      const { setError } = this.props;
      setError(errorMessage);
    }.bind(this));
  }

  onShowDetail(id) {
    const { router } = this.props;
    router.navigate('/detail', { selectedBook: id });
  }
  
  render() {
    const { router } = this.props;
    const { items } = this.state;

    return (
      <div className="catalog">
        {items && items.length ? items.map(item => (
          <CatalogItem
            key={item.name}
            item={item}
            isOnWishList
            onShowDetail={() => this.onShowDetail(item.id)}
            onRemoveFromWishList={() => this.onRemoveFromWishList(item.id)}
            hideCartActions
            mode="list"
          />
        )) :
        (<EmptySection
          router={router}
          label="Your wishlist is empty"
        />
        )}
      </div>
    );
  }
}
